// ===================== DATA =====================
const AVATARS = [
  'https://i.pravatar.cc/150?img=1',
  'https://i.pravatar.cc/150?img=2',
  'https://i.pravatar.cc/150?img=3',
  'https://i.pravatar.cc/150?img=4',
  'https://i.pravatar.cc/150?img=5',
  'https://i.pravatar.cc/150?img=6',
  'https://i.pravatar.cc/150?img=7',
  'https://i.pravatar.cc/150?img=8',
  'https://i.pravatar.cc/150?img=9',
  'https://i.pravatar.cc/150?img=10',
];

const POST_IMAGES = [
  'https://picsum.photos/seed/insta1/600/600',
  'https://picsum.photos/seed/insta2/600/600',
  'https://picsum.photos/seed/insta3/600/600',
  'https://picsum.photos/seed/insta4/600/600',
  'https://picsum.photos/seed/insta5/600/600',
  'https://picsum.photos/seed/insta6/600/600',
  'https://picsum.photos/seed/insta7/600/600',
  'https://picsum.photos/seed/insta8/600/600',
];

const CAPTIONS = [
  'Golden hour never disappoints ✨',
  'Living my best life 🌿',
  'Every moment is a fresh beginning 🌅',
  'Not all those who wander are lost 🗺️',
  'Good vibes only 🌊',
  'Chase the light 📸',
  'Adventure awaits 🏔️',
  'Just another magic Monday ☀️',
];

const LOCATIONS = ['New York, NY', 'Los Angeles, CA', 'Paris, France', 'Tokyo, Japan', 'Bali, Indonesia', 'London, UK'];

const suggestions = [
  { username: 'alex_photo', name: 'Alex Johnson', avatar: AVATARS[1], following: false },
  { username: 'sara_vibes', name: 'Sara Williams', avatar: AVATARS[2], following: false },
  { username: 'mike_travels', name: 'Mike Davis', avatar: AVATARS[3], following: false },
  { username: 'luna_art', name: 'Luna Chen', avatar: AVATARS[4], following: false },
  { username: 'jake_fit', name: 'Jake Martinez', avatar: AVATARS[5], following: false },
];

const storyUsers = [
  { username: 'alex_photo', avatar: AVATARS[1], image: 'https://picsum.photos/seed/s1/400/700' },
  { username: 'sara_vibes', avatar: AVATARS[2], image: 'https://picsum.photos/seed/s2/400/700' },
  { username: 'mike_travels', avatar: AVATARS[3], image: 'https://picsum.photos/seed/s3/400/700' },
  { username: 'luna_art', avatar: AVATARS[4], image: 'https://picsum.photos/seed/s4/400/700' },
  { username: 'jake_fit', avatar: AVATARS[5], image: 'https://picsum.photos/seed/s5/400/700' },
];

let currentUser = {
  username: '',
  name: 'My Name',
  bio: '✨ Living life one photo at a time',
  avatar: AVATARS[0],
};

let posts = [];
let currentPostIndex = null;
let storyTimer = null;

// ===================== AUTH =====================
function login() {
  const u = document.getElementById('auth-username').value.trim() || 'user_' + Math.floor(Math.random() * 9999);
  currentUser.username = u;
  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  initApp();
}

function logout() {
  document.getElementById('auth-screen').classList.remove('hidden');
  document.getElementById('app').classList.add('hidden');
}

// ===================== INIT =====================
function initApp() {
  setUserUI();
  generatePosts();
  renderStories();
  renderSuggestions();
  renderExplore();
  renderNotifications();
  renderDMs();
  renderProfileGrid();
  showPage('feed');
}

function setUserUI() {
  document.querySelectorAll('#nav-avatar-img, #sidebar-avatar, #profile-avatar, #story-self-img, #edit-avatar-img').forEach(el => {
    el.src = currentUser.avatar;
  });
  const upAvatar = document.getElementById('upload-avatar');
  if (upAvatar) upAvatar.src = currentUser.avatar;
  document.getElementById('sidebar-username').textContent = currentUser.username;
  document.getElementById('sidebar-name').textContent = currentUser.name;
  document.getElementById('profile-username').textContent = currentUser.username;
  document.getElementById('profile-bio').textContent = currentUser.bio;
  document.getElementById('msg-username-header').textContent = currentUser.username;
  document.getElementById('upload-username').textContent = currentUser.username;
  document.getElementById('edit-name').value = currentUser.name;
  document.getElementById('edit-username-field').value = currentUser.username;
  document.getElementById('edit-bio').value = currentUser.bio;
}

// ===================== POSTS =====================
function generatePosts() {
  posts = [];
  for (let i = 0; i < 6; i++) {
    const user = suggestions[i % suggestions.length];
    posts.push({
      id: i,
      username: user.username,
      avatar: user.avatar,
      location: LOCATIONS[i % LOCATIONS.length],
      image: POST_IMAGES[i % POST_IMAGES.length],
      caption: CAPTIONS[i % CAPTIONS.length],
      likes: Math.floor(Math.random() * 2000) + 100,
      liked: false,
      saved: false,
      time: `${i + 1} hour${i === 0 ? '' : 's'} ago`,
      comments: [
        { username: suggestions[(i + 1) % suggestions.length].username, avatar: suggestions[(i + 1) % suggestions.length].avatar, text: 'Amazing shot! 🔥' },
        { username: suggestions[(i + 2) % suggestions.length].username, avatar: suggestions[(i + 2) % suggestions.length].avatar, text: 'Love this ❤️' },
      ],
    });
  }
  renderPosts();
}

function renderPosts() {
  const container = document.getElementById('posts-container');
  container.innerHTML = '';
  posts.forEach((post, idx) => {
    container.innerHTML += buildPostHTML(post, idx);
  });
  // Update post count in profile
  document.getElementById('stat-posts').textContent = posts.filter(p => p.username === currentUser.username).length;
}

function buildPostHTML(post, idx) {
  return `
  <div class="post-card" id="post-card-${idx}">
    <div class="post-header">
      <div class="story-ring" style="width:40px;height:40px;padding:2px;">
        <img class="post-avatar-inner" src="${post.avatar}" alt="${post.username}" style="width:36px;height:36px;" onclick="showPage('explore')"/>
      </div>
      <div>
        <div class="post-username">${post.username}</div>
        <div class="post-location">${post.location}</div>
      </div>
      <i class="fa-solid fa-ellipsis post-more"></i>
    </div>
    <img class="post-image" src="${post.image}" alt="post" onclick="openPostModal(${idx})" loading="lazy"/>
    <div class="post-actions">
      <button class="post-action-btn ${post.liked ? 'liked' : ''}" onclick="toggleLike(${idx})" id="like-btn-${idx}">
        <i class="${post.liked ? 'fa-solid' : 'fa-regular'} fa-heart"></i>
      </button>
      <button class="post-action-btn" onclick="openPostModal(${idx})">
        <i class="fa-regular fa-comment"></i>
      </button>
      <button class="post-action-btn">
        <i class="fa-regular fa-paper-plane"></i>
      </button>
      <button class="post-action-btn save-btn ${post.saved ? 'saved' : ''}" onclick="toggleSave(${idx})" id="save-btn-${idx}">
        <i class="${post.saved ? 'fa-solid' : 'fa-regular'} fa-bookmark"></i>
      </button>
    </div>
    <div class="post-likes" id="likes-count-${idx}">${post.likes.toLocaleString()} likes</div>
    <div class="post-caption"><span>${post.username}</span> ${post.caption}</div>
    <div class="post-comments-link" onclick="openPostModal(${idx})">View all ${post.comments.length} comments</div>
    <div class="post-time">${post.time}</div>
    <div class="comment-input-row">
      <input type="text" placeholder="Add a comment..." id="comment-input-${idx}" oninput="togglePostBtn(${idx})"/>
      <button id="comment-btn-${idx}" onclick="addComment(${idx})">Post</button>
    </div>
  </div>`;
}

function toggleLike(idx) {
  const post = posts[idx];
  post.liked = !post.liked;
  post.likes += post.liked ? 1 : -1;

  const btn = document.getElementById(`like-btn-${idx}`);
  btn.classList.toggle('liked', post.liked);
  btn.querySelector('i').className = (post.liked ? 'fa-solid' : 'fa-regular') + ' fa-heart';
  btn.classList.add('heart-pop');
  setTimeout(() => btn.classList.remove('heart-pop'), 300);
  document.getElementById(`likes-count-${idx}`).textContent = post.likes.toLocaleString() + ' likes';
}

function toggleSave(idx) {
  const post = posts[idx];
  post.saved = !post.saved;
  const btn = document.getElementById(`save-btn-${idx}`);
  btn.classList.toggle('saved', post.saved);
  btn.querySelector('i').className = (post.saved ? 'fa-solid' : 'fa-regular') + ' fa-bookmark';
}

function togglePostBtn(idx) {
  const val = document.getElementById(`comment-input-${idx}`).value.trim();
  document.getElementById(`comment-btn-${idx}`).classList.toggle('active', val.length > 0);
}

function addComment(idx) {
  const input = document.getElementById(`comment-input-${idx}`);
  const text = input.value.trim();
  if (!text) return;
  posts[idx].comments.push({ username: currentUser.username, avatar: currentUser.avatar, text });
  input.value = '';
  document.getElementById(`comment-btn-${idx}`).classList.remove('active');
  document.getElementById(`post-card-${idx}`).querySelector('.post-comments-link').textContent = `View all ${posts[idx].comments.length} comments`;
}

// ===================== STORIES =====================
function renderStories() {
  const bar = document.querySelector('.stories-bar');
  // Keep self story, add others
  storyUsers.forEach(u => {
    const item = document.createElement('div');
    item.className = 'story-item';
    item.innerHTML = `
      <div class="story-ring">
        <img src="${u.avatar}" alt="${u.username}"/>
      </div>
      <span>${u.username}</span>`;
    item.onclick = () => viewStory(u.username, u.avatar, u.image);
    bar.appendChild(item);
  });
  // Self avatar
  document.getElementById('story-self-img').src = currentUser.avatar;
}

function viewStory(username, avatar, image) {
  const av = avatar || currentUser.avatar;
  const img = image || 'https://picsum.photos/seed/selfstory/400/700';
  document.getElementById('story-img').src = img;
  document.getElementById('story-avatar').src = av;
  document.getElementById('story-username').textContent = username;
  document.getElementById('story-modal').classList.remove('hidden');
  // Reset animation
  const bar = document.getElementById('story-bar');
  bar.style.animation = 'none';
  bar.offsetHeight; // reflow
  bar.style.animation = 'storyProgress 5s linear forwards';
  if (storyTimer) clearTimeout(storyTimer);
  storyTimer = setTimeout(closeStoryModal, 5000);
}

function closeStoryModal() {
  document.getElementById('story-modal').classList.add('hidden');
  if (storyTimer) clearTimeout(storyTimer);
}

// ===================== SUGGESTIONS =====================
function renderSuggestions() {
  const list = document.getElementById('suggestions-list');
  list.innerHTML = '';
  suggestions.forEach((s, i) => {
    list.innerHTML += `
      <div class="suggestion-item">
        <img src="${s.avatar}" alt="${s.username}"/>
        <div>
          <div class="sug-username">${s.username}</div>
          <div class="sug-sub">Suggested for you</div>
        </div>
        <button class="follow-btn ${s.following ? 'following' : ''}" id="follow-btn-${i}" onclick="toggleFollow(${i})">
          ${s.following ? 'Following' : 'Follow'}
        </button>
      </div>`;
  });
}

function toggleFollow(i) {
  suggestions[i].following = !suggestions[i].following;
  const btn = document.getElementById(`follow-btn-${i}`);
  btn.textContent = suggestions[i].following ? 'Following' : 'Follow';
  btn.classList.toggle('following', suggestions[i].following);
}

// ===================== EXPLORE =====================
function renderExplore() {
  const grid = document.getElementById('explore-grid');
  grid.innerHTML = '';
  for (let i = 0; i < 15; i++) {
    const likes = Math.floor(Math.random() * 5000) + 200;
    const comments = Math.floor(Math.random() * 500) + 10;
    const seed = 'explore' + i;
    grid.innerHTML += `
      <div class="explore-cell" onclick="openPostModal(${i % posts.length})">
        <img src="https://picsum.photos/seed/${seed}/400/400" loading="lazy" alt="explore"/>
        <div class="explore-overlay">
          <span><i class="fa-solid fa-heart"></i> ${likes.toLocaleString()}</span>
          <span><i class="fa-solid fa-comment"></i> ${comments}</span>
        </div>
      </div>`;
  }
}

// ===================== NOTIFICATIONS =====================
function renderNotifications() {
  const list = document.getElementById('notif-list');
  const notifs = [
    { user: suggestions[0], type: 'liked your photo.', time: '2m', postImg: POST_IMAGES[0] },
    { user: suggestions[1], type: 'started following you.', time: '15m', postImg: null },
    { user: suggestions[2], type: 'commented: "Love this! 🔥"', time: '1h', postImg: POST_IMAGES[1] },
    { user: suggestions[3], type: 'liked your photo.', time: '3h', postImg: POST_IMAGES[2] },
    { user: suggestions[4], type: 'mentioned you in a comment.', time: '5h', postImg: POST_IMAGES[3] },
  ];
  list.innerHTML = notifs.map(n => `
    <div class="notif-item">
      <img src="${n.user.avatar}" alt="${n.user.username}"/>
      <div class="notif-text">
        <b>${n.user.username}</b> ${n.type}
        <div class="notif-time">${n.time}</div>
      </div>
      ${n.postImg ? `<img class="notif-post-thumb" src="${n.postImg}" alt="post"/>` : `<button class="follow-btn">Follow</button>`}
    </div>`).join('');
}

// ===================== MESSAGES =====================
function renderDMs() {
  const list = document.getElementById('dm-list');
  list.innerHTML = suggestions.map(s => `
    <div class="dm-item">
      <img src="${s.avatar}" alt="${s.username}"/>
      <div>
        <div class="dm-name">${s.username}</div>
        <div class="dm-preview">Tap to send a message</div>
      </div>
    </div>`).join('');
}

// ===================== PROFILE GRID =====================
function renderProfileGrid() {
  const grid = document.getElementById('profile-grid');
  const userPosts = posts.filter(p => p.username === currentUser.username);
  grid.innerHTML = '';
  if (userPosts.length === 0) {
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-muted);">Share your first photo!</div>`;
    return;
  }
  userPosts.forEach((p, i) => {
    grid.innerHTML += `
      <div class="profile-thumb" onclick="openPostModal(${p.id})">
        <img src="${p.image}" alt="post" loading="lazy"/>
        <div class="explore-overlay">
          <span><i class="fa-solid fa-heart"></i> ${p.likes.toLocaleString()}</span>
          <span><i class="fa-solid fa-comment"></i> ${p.comments.length}</span>
        </div>
      </div>`;
  });
}

// ===================== POST MODAL =====================
function openPostModal(idx) {
  if (!posts[idx]) return;
  const post = posts[idx];
  currentPostIndex = idx;
  document.getElementById('post-modal-image').src = post.image;
  document.getElementById('post-modal-avatar').src = post.avatar;
  document.getElementById('post-modal-username').textContent = post.username;
  document.getElementById('pm-likes-count').textContent = post.likes.toLocaleString() + ' likes';

  const likeIcon = document.getElementById('pm-like-icon');
  likeIcon.className = (post.liked ? 'fa-solid' : 'fa-regular') + ' fa-heart pm-icon' + (post.liked ? ' liked' : '');

  const comments = document.getElementById('post-modal-comments');
  comments.innerHTML = `
    <div class="pm-comment">
      <img src="${post.avatar}" alt="${post.username}"/>
      <div><b>${post.username}</b> ${post.caption}</div>
    </div>`;
  post.comments.forEach(c => {
    comments.innerHTML += `
      <div class="pm-comment">
        <img src="${c.avatar}" alt="${c.username}"/>
        <div><b>${c.username}</b> ${c.text}</div>
      </div>`;
  });

  document.getElementById('post-modal').classList.remove('hidden');
}

function closePostModal(e) {
  if (e.target === document.getElementById('post-modal')) {
    document.getElementById('post-modal').classList.add('hidden');
  }
}

function togglePostModalLike() {
  if (currentPostIndex === null) return;
  toggleLike(currentPostIndex);
  const post = posts[currentPostIndex];
  const likeIcon = document.getElementById('pm-like-icon');
  likeIcon.className = (post.liked ? 'fa-solid' : 'fa-regular') + ' fa-heart pm-icon' + (post.liked ? ' liked' : '');
  document.getElementById('pm-likes-count').textContent = post.likes.toLocaleString() + ' likes';
}

function addModalComment() {
  if (currentPostIndex === null) return;
  const input = document.getElementById('pm-comment-input');
  const text = input.value.trim();
  if (!text) return;
  posts[currentPostIndex].comments.push({ username: currentUser.username, avatar: currentUser.avatar, text });
  input.value = '';
  openPostModal(currentPostIndex); // refresh
}

// ===================== UPLOAD =====================
function openUpload() {
  document.getElementById('upload-modal').classList.remove('hidden');
  document.getElementById('upload-drop').classList.remove('hidden');
  document.getElementById('preview-img').classList.add('hidden');
  document.getElementById('upload-form').classList.add('hidden');
  document.getElementById('caption-input').value = '';
  document.getElementById('char-count').textContent = '0';
  document.getElementById('file-input').value = '';
  document.getElementById('upload-avatar').src = currentUser.avatar;
  document.getElementById('upload-username').textContent = currentUser.username;
}

function closeUpload(e) {
  if (e.target === document.getElementById('upload-modal')) {
    document.getElementById('upload-modal').classList.add('hidden');
  }
}

function previewImage(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    const src = ev.target.result;
    document.getElementById('upload-drop').classList.add('hidden');
    document.getElementById('upload-form').classList.remove('hidden');
    document.getElementById('mini-preview').src = src;
    document.getElementById('upload-form').querySelector('img').src = src;

    const captionInput = document.getElementById('caption-input');
    captionInput.oninput = () => {
      document.getElementById('char-count').textContent = captionInput.value.length;
    };
  };
  reader.readAsDataURL(file);
}

function submitPost() {
  const form = document.getElementById('upload-form');
  if (form.classList.contains('hidden')) { alert('Please select an image first!'); return; }
  const imgSrc = document.getElementById('mini-preview').src;
  const caption = document.getElementById('caption-input').value.trim() || '✨';
  const newPost = {
    id: posts.length,
    username: currentUser.username,
    avatar: currentUser.avatar,
    location: 'My Location',
    image: imgSrc,
    caption,
    likes: 0,
    liked: false,
    saved: false,
    time: 'Just now',
    comments: [],
  };
  posts.unshift(newPost);
  // Fix ids
  posts.forEach((p, i) => p.id = i);
  renderPosts();
  renderProfileGrid();
  document.getElementById('upload-modal').classList.add('hidden');
  showPage('profile');
}

// ===================== EDIT PROFILE =====================
function openEditProfile() {
  document.getElementById('edit-avatar-img').src = currentUser.avatar;
  document.getElementById('edit-name').value = currentUser.name;
  document.getElementById('edit-username-field').value = currentUser.username;
  document.getElementById('edit-bio').value = currentUser.bio;
  document.getElementById('edit-modal').classList.remove('hidden');
}

function closeEditModal(e) {
  if (e.target === document.getElementById('edit-modal')) {
    document.getElementById('edit-modal').classList.add('hidden');
  }
}

function saveProfile() {
  currentUser.name = document.getElementById('edit-name').value.trim() || currentUser.name;
  currentUser.username = document.getElementById('edit-username-field').value.trim() || currentUser.username;
  currentUser.bio = document.getElementById('edit-bio').value.trim();
  document.getElementById('edit-modal').classList.add('hidden');
  setUserUI();
}

function changeAvatar(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    currentUser.avatar = ev.target.result;
    document.getElementById('edit-avatar-img').src = currentUser.avatar;
    setUserUI();
  };
  reader.readAsDataURL(file);
}

// ===================== SEARCH =====================
function filterSearch() {
  const q = document.getElementById('search-input').value.trim().toLowerCase();
  const dropdown = document.getElementById('search-dropdown');
  if (!q) { dropdown.classList.remove('active'); return; }
  const filtered = suggestions.filter(s => s.username.includes(q) || s.name.toLowerCase().includes(q));
  if (filtered.length === 0) { dropdown.classList.remove('active'); return; }
  dropdown.innerHTML = filtered.map(s => `
    <div class="search-item" onclick="showPage('explore')">
      <img src="${s.avatar}" alt="${s.username}"/>
      <div>
        <div class="si-name">${s.username}</div>
        <div class="si-sub">${s.name}</div>
      </div>
    </div>`).join('');
  dropdown.classList.add('active');
}

document.addEventListener('click', (e) => {
  if (!e.target.closest('.nav-search')) {
    document.getElementById('search-dropdown').classList.remove('active');
  }
});

// ===================== NAVIGATION =====================
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-icon').forEach(i => i.classList.remove('active'));
  const page = document.getElementById('page-' + name);
  if (page) page.classList.add('active');

  const iconMap = { feed: 0, messages: 1, explore: 3, notifications: 4 };
  const icons = document.querySelectorAll('.nav-icon');
  if (iconMap[name] !== undefined) icons[iconMap[name]].classList.add('active');

  // Close search dropdown
  document.getElementById('search-dropdown').classList.remove('active');
  document.getElementById('search-input').value = '';
}

// ===================== KEYBOARD =====================
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay').forEach(m => m.classList.add('hidden'));
    closeStoryModal();
  }
});

// Auto-login for demo
window.onload = () => {
  document.getElementById('auth-username').value = 'demo_user';
};
